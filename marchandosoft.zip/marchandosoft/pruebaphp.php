<?php
   // Incluimos el fichero de conexión
require_once "config.php";
$sql = "SELECT * FROM Articulos";
$result = mysqli_query($link,$sql);?>
<table>
 <tr><th>ID Artículo</th><th>Nombre artículo</th><th>Pvp</th><th>Tipo</th><th>Stock</th></tr>
<?php if(mysqli_num_rows($result)>0) {
 while($row = mysqli_fetch_assoc($result)) { ?>
 <style>
 table {
  border-collapse: collapse;
}

table, th, td {
  border: 1px solid black;
  text-align: center;
}
</style>
 <?php
            echo "<tr><td>".$row["idArticulos"]."</td><td>". $row["nombreart"] . "</td><td>" . $row["pvpart"]. "</td><td>" . $row["tipoart"] . "</td><td>".$row["stock"]."</td></tr>";
        }
    }else {
        echo "0 results";
    }
?>
</table>