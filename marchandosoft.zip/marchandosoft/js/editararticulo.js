$(document).ready(function(){
  $("#edit").click(function(){
    $(".editar").slideToggle();
    datosarticuloamodificar();
  });
});