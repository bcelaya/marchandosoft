<!DOCTYPE html>
<html lang="es">
<head>
  <title>MarchandoSoft - gestión mesas</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/mesas.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
</head>
<body>

<div class="container">
  <div class="top">
  <span id="camarero">Nombre camarero: </span><span id="logout"><a href src="logout.php"><i class="fas fa-sign-out-alt text-right"></i>Cerrar sesión</a></span>
  </div>
  <div class="medium">
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
      <p>Esto es el medium</p>
  </div>
  <footer>
      <span>Esto es el footer</span>
  </footer>
</div>
</body>
</html>