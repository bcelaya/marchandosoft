<?php 
session_start();

$_SESSION["nombre"]=["Bruno","Dafne","Maria"];
$_SESSION["mesa"]=1;
echo "mi nombre es ".$_SESSION["nombre"][1];
echo "<br>mi mesa es la ".$_SESSION["mesa"];
?>