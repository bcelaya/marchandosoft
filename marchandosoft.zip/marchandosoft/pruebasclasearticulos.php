<?php
include 'articulos.php';
$query = 'SELECT idArticulos FROM Articulos';
$objetos = array ();
$result = mysqli_query($link,$query);
print_r($result);
echo "<br>Aquí va lo que saco del mysqli_fetch_array:<br>";
while ($row = mysqli_fetch_array($result,MYSQLI_NUM)){
    //printf ("%s \n",$row[0]);
    $obj = new articulos($row[0]);
    array_push($objetos,$obj);
}

var_dump($objetos);

/*
foreach ($objetos as $platos){
    echo "<br>ID plato: $platos->getIdart()";
    echo "<br>Nombre plato: $platos->getNomart()";
    echo "<br>Pvp plato: $platos->getPvpart()";
    echo "<br>Tipo plato: $platos->getTipoart()";
    echo "<br>Stock plato: $platos->getStock()";
}
*/
?>