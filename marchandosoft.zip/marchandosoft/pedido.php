<?php
class pedido{
    private $idpedido;
    private $fecha;
    private $lista = array();
    
    function __construct($idpedido) {
        $sql = "SELECT * FROM pedido WHERE idpedido=$idpedido";
        $link = mysqli_connect('localhost', 'brunozm', '123', 'marchando') or die('No se puede conectar con la BBDD.');
        $resultset = mysqli_query($link,$sql) or die ("no se ha podido hacer la consulta");
        while($row=mysqli_fetch_array($resultset)){
            $this->idpedido=$idpedido;
            $this->fecha=$row[1];
            
            }
        $sql2 = "SELECT idlinea FROM pedidos WHERE pedido_idpedido=$idpedido";
        $resultset2 = mysqli_query($link, $sql2);
        while($row2= mysqli_fetch_array($resultset2)){
            $linea = new lineapedido($row2[0]);
            array_push($this->lista,$linea);
        }
        return $this;
    }
    
    static public function lineaspedido($idpedidos){
        $lista = array();
        
        while ($row= mysqli_fetch_array($resultset)){
            $linea = new $pedido();
        }
        
        
    }
    
    function getIdpedido() {
        return $this->idpedido;
    }

    function getFecha() {
        return $this->fecha;
    }

    function getLista() {
        return $this->lista;
    }

    function setIdpedido($idpedido) {
        $this->idpedido = $idpedido;
    }

    function setFecha($fecha) {
        $this->fecha = $fecha;
    }

    function setLista($lista) {
        $this->lista = $lista;
    }




    
}


