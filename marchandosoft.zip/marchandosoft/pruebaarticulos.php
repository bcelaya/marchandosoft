<?php
require_once 'articulos.php';
// Incluimos el fichero de conexión
require_once 'config.php';
// Incluimos sesión
require_once 'controlsesion.php';
// Empezamos por las comidas
$_tipoart = "comidas";
// $_ficha = 'bebidas';
$sql = "SELECT * FROM Articulos WHERE tipoart='$_tipoart'";
$result = mysqli_query($link,$sql);
var_dump($_tipoart);
//creamos boton de comida con los items que hay
if (mysqli_num_rows($result) > 0) {
    // output data of each row ?>
    <!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="/css/bootstrap.min.css">
  <link rel="stylesheet" href="/css/pedidomesa.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

    <table class="table-striped table-bordered" id="tablacomida">
  <?php  while($row = mysqli_fetch_assoc($result)) {
        echo "<tr><td id='idart'>".$row['idArticulos']."</td><td id='nomart'>" . $row["nombreart"]. "</td><td id='pvpart'>" . $row["pvpart"]. "</td><td id='tipoart'>" . $row["tipoart"] . "</td><td id='stock'>" . $row["stock"] . "</td></tr>";
    }
} else {
    echo "0 results";
}
?></table>
<?php
$ensalada = new Articulos(1,"ensalada",2.5,"comidas",5);
echo "Aqui como accedemos al nombre pq es private:<br>";
echo $ensalada->getNomart();
echo "Mismo pero ahora con el pvpart<br>";
echo $ensalada->getPvpart();
echo "<br>Holaaaa";
?>