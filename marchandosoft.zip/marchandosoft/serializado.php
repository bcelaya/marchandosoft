<?php 
require_once 'config.php';
$sql = "SELECT * FROM Articulos";
$result = mysqli_query($link,$sql);
/*echo "Resultado resulset: ";
print_r($result);
$serializado = serialize($result);
echo "esto es el resultado de serializado: $serializado <br>";
//$result = array(); 
*/
$num = mysqli_num_rows($result);
for ($i = 0; $i < $num; $i++)
{
    $myArray[] = mysqli_fetch_assoc($result);
}
print_r($myArray);
// a ver si consigo encontrar la longitud del array
$longitud = count($myArray);
echo "<br><br>La longitud del array es de: ".$longitud."<br><br>";
echo "<br><br>Imprimo esto a ver: ";
for ($i= 0; $i<$longitud;$i++){
    echo "Resultado: ".$myArray[$i]['nombreart']."<br><br>";
}
$serializado = serialize($myArray);
print_r($serializado);
$deserializado = unserialize($serializado);
echo "<br><br>Deserializado:<br><br>";
print_r($deserializado);
?>