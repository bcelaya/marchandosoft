<?php
include 'articulos.php';


$query = 'SELECT * FROM Articulos';
$objetos2 = array ();
$result = mysqli_query($link,$query);
print_r($result);
echo "<br>Aquí va lo que saco del mysqli_fetch_array:<br>";
while ($row = mysqli_fetch_array($result,MYSQLI_NUM)){
    printf ("%s %s \n",$row[0],$row[1]);
    $obj = new articulos($row[1]);
    array_push($objetos2,$obj);
}

$objeto2 = new articulos('1');
var_dump($objetos2);
$objeto2->getNomart();
?>
