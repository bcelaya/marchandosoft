<?php
class lineapedido{
    private $fecha;
    private $Articulos_idArticulos;
    private $cantidad_pedida;
    private $cantidad_servida;
    private $pedido_idpedido;
    private $idlinea;
    private $idArticulos;
    private $nombreart;
    private $pvpart;
    private $tipoart;

    function __construct($idlinea) {
        $sql = "SELECT * FROM lineapedido WHERE idlinea=$idlinea";
        $link = mysqli_connect('localhost', 'brunozm', '123', 'marchando') or die('No se puede conectar con la BBDD.');
        $resultset = mysqli_query($link,$sql) or die ("no se ha podido hacer la consulta");
        while($row=mysqli_fetch_array($resultset)){
            $this->fecha=$row[0];
            $this->Articulos_idArticulos=$row[1];
            $this->cantidad_pedida=$row[2];
            $this->cantidad_servida=$row[3];
            $this->pedido_idpedido=$row[4];
            $this->idlinea=$idlinea;
        }
        return $this;
    }
    
    static public function lineaspedido($idpedidos){
        $lista = array();
        
        while ($row= mysqli_fetch_array($resultset)){
            $linea = new $pedido();
        }
        
        
    }
    
    function getFecha() {
        return $this->fecha;
    }

    function getArticulos_idArticulos() {
        return $this->Articulos_idArticulos;
    }

    function getCantidad_pedida() {
        return $this->cantidad_pedida;
    }

    function getCantidad_servida() {
        return $this->cantidad_servida;
    }

    function getPedido_idpedido() {
        return $this->pedido_idpedido;
    }

    function getIdlinea() {
        return $this->idlinea;
    }

    function getIdArticulos() {
        return $this->idArticulos;
    }

    function getNombreart() {
        return $this->nombreart;
    }

    function getPvpart() {
        return $this->pvpart;
    }

    function getTipoart() {
        return $this->tipoart;
    }

    function setFecha($fecha) {
        $this->fecha = $fecha;
    }

    function setArticulos_idArticulos($Articulos_idArticulos) {
        $this->Articulos_idArticulos = $Articulos_idArticulos;
    }

    function setCantidad_pedida($cantidad_pedida) {
        $this->cantidad_pedida = $cantidad_pedida;
    }

    function setCantidad_servida($cantidad_servida) {
        $this->cantidad_servida = $cantidad_servida;
    }

    function setPedido_idpedido($pedido_idpedido) {
        $this->pedido_idpedido = $pedido_idpedido;
    }

    function setIdlinea($idlinea) {
        $this->idlinea = $idlinea;
    }

    function setIdArticulos($idArticulos) {
        $this->idArticulos = $idArticulos;
    }

    function setNombreart($nombreart) {
        $this->nombreart = $nombreart;
    }

    function setPvpart($pvpart) {
        $this->pvpart = $pvpart;
    }

    function setTipoart($tipoart) {
        $this->tipoart = $tipoart;
    }

    
}


