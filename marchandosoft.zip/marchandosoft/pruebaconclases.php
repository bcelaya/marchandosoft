<?php
// incluimos archivo de clase
include 'articulos.php';
$objeto = new Articulos(7);
echo "<br>hola<br>";
echo $objeto->getNomart();
echo "<br>".$objeto->getTipoart();
?>
<button id="botonaco" onclick='<?php $objeto->json();
?>
